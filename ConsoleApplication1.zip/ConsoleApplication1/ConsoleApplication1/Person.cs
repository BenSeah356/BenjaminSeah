﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Person
    {
        public int Id { get; set; }
        public Wallet[] Wallets { get; set; }
        public float PersonInterest { get; set; }

        public float calculatePersonInterest(Wallet[] Wallets)
        {
            PersonInterest = 0;
            foreach (Wallet wallet in Wallets)
            {
                if (wallet.PersonId == this.Id)
                {
                    float walletinteresttemp = 0;
                    walletinteresttemp = wallet.calculateWalletInterest(wallet.Cards);
                    PersonInterest = PersonInterest + walletinteresttemp;
                }
                
            }
            return PersonInterest;
        }
    }
}
