﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Wallet
    {
        public int Id { get; set; }
        public int PersonId { get; set; }
        public Card[] Cards { get; set; }
        public float WalletInterest { get; set; }

        public float calculateWalletInterest(Card[] Cards)
        {
            WalletInterest = 0;
            foreach (Card card in Cards)
            {

                if (card.WalletId == this.Id)
                {
                    float cardinteresttemp = 0;
                    cardinteresttemp = card.calculateCardInterest(card.Balance, card.CardType);
                    WalletInterest = WalletInterest + cardinteresttemp;
                }                
            }
            return WalletInterest;
        }
    }
}
