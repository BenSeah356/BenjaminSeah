﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApplication1;
//MS Test framework
namespace ConsoleApplication.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        //1 person has 1 wallet and 3 cards (1 Visa, 1 MC, 1 Discover) – Each Card has a balance of $100 –
        //calculate the total interest(simple interest) for this person and per card.
        public void TestMethod1()
        {
            //Arrage
            //create cards
            //Card 1
            var Cards = new Card[3];
            Cards[0] = new Card();
            Cards[0].Id = 1;
            Cards[0].WalletId = 1;
            Cards[0].CardType = "Visa";
            Cards[0].Balance = 100f;
            Cards[0].Interest = 0f;
            //Card 2
            Cards[1] = new Card();
            Cards[1].Id = 2;
            Cards[1].WalletId = 1;
            Cards[1].CardType = "MC";
            Cards[1].Balance = 100f;
            Cards[1].Interest = 0f;
            //Card 3
            Cards[2] = new Card();
            Cards[2].Id = 3;
            Cards[2].WalletId = 1;
            Cards[2].CardType = "Discover";
            Cards[2].Balance = 100f;
            Cards[2].Interest = 0f;
            
            //create wallets
            //Wallet 1
            var Wallets = new Wallet[1];
            Wallets[0] = new Wallet();
            Wallets[0].Id = 1;
            Wallets[0].PersonId = 1;
            Wallets[0].Cards = Cards;
            Wallets[0].WalletInterest = 0f;

            //create people
            //Person 1
            var Person = new Person[1];
            Person[0] = new Person();
            Person[0].Id = 1;
            Person[0].Wallets = Wallets;
            Person[0].PersonInterest = 0f;

            float personInterestExpected = 16f;
            float visaCardInterestExpected = 10f;
            float mcCardInterestExpected = 5f;
            float discoverCardInterestExpected = 1f;

            //Act
            float personInterestActual = Person[0].calculatePersonInterest(Person[0].Wallets);
            Console.Write(personInterestActual);
            float visaCardInterestActual = Cards[0].calculateCardInterest(Cards[0].Balance, Cards[0].CardType);
            Console.Write(visaCardInterestActual);
            float mcCardInterestActual = Cards[1].calculateCardInterest(Cards[1].Balance, Cards[1].CardType);
            Console.Write(mcCardInterestActual);
            float discoverCardInterestActual = Cards[2].calculateCardInterest(Cards[2].Balance, Cards[2].CardType);
            Console.Write(discoverCardInterestActual);


            //Assert
            //Person Total Interest Test
            Assert.AreEqual(personInterestExpected, personInterestActual);
            //Visa Card Interest Test
            Assert.AreEqual(visaCardInterestExpected, visaCardInterestActual);
            //MasterCard Interest Test
            Assert.AreEqual(mcCardInterestExpected, mcCardInterestActual);
            //Discover Card Interest Test
            Assert.AreEqual(discoverCardInterestExpected, discoverCardInterestActual);
        }

        [TestMethod]
        //1 person has 2 wallets Wallet 1 has a Visa and Discover , wallet 2 a MC - each card has $100 balance -
        //calculate the total interest(simple interest) for this person and interest per wallet
        public void TestMethod2()
        {
            //Arrage
            //create cards
            //Card 1
            var Cards = new Card[3];
            Cards[0] = new Card();
            Cards[0].Id = 1;
            Cards[0].WalletId = 1;
            Cards[0].CardType = "Visa";
            Cards[0].Balance = 100f;
            Cards[0].Interest = 0f;
            //Card 2
            Cards[1] = new Card();
            Cards[1].Id = 2;
            Cards[1].WalletId = 1;
            Cards[1].CardType = "Discover";
            Cards[1].Balance = 100f;
            Cards[1].Interest = 0f;
            //Card 3
            Cards[2] = new Card();
            Cards[2].Id = 3;
            Cards[2].WalletId = 2;
            Cards[2].CardType = "MC";
            Cards[2].Balance = 100f;
            Cards[2].Interest = 0f;

            //create wallets
            //Wallet 1
            var Wallets = new Wallet[2];
            Wallets[0] = new Wallet();
            Wallets[0].Id = 1;
            Wallets[0].PersonId = 1;
            Wallets[0].Cards = Cards;
            Wallets[0].WalletInterest = 0f;
            //Wallet 2
            Wallets[1] = new Wallet();
            Wallets[1].Id = 2;
            Wallets[1].PersonId = 1;
            Wallets[1].Cards = Cards;
            Wallets[1].WalletInterest = 0f;

            //create people
            //Person 1
            var Person = new Person[1];
            Person[0] = new Person();
            Person[0].Id = 1;
            Person[0].Wallets = Wallets;
            Person[0].PersonInterest = 0f;

            float personInterestExpected = 16f;
            float wallet1InterestExpected = 11f;
            float wallet2InterestExpected = 5f;
            
            //Act
            float personInterestActual = Person[0].calculatePersonInterest(Person[0].Wallets);
            float wallet1InterestActual = Wallets[0].WalletInterest;
            float wallet2InterestActual = Wallets[1].WalletInterest;

            //Assert
            //Person Total Interest Test
            Assert.AreEqual(personInterestExpected, personInterestActual);
            //Wallet 1 Interest Test
            Assert.AreEqual(wallet1InterestExpected, wallet1InterestActual);
            //Wallet 2 Interest Test
            Assert.AreEqual(wallet2InterestExpected, wallet2InterestActual);

        }

        [TestMethod]
        //2 people have 1 wallet each, person 1 has 1 wallet with 3 cards (1 MC, 1 Visa, 1 Discover), person 2 has
        //1 wallet with 2 cards(1 Visa, 1 MC) all cards in all wallets for both people have a $100 balance -
        //calculate the total interest(simple interest) for each person and interest per wallet
        public void TestMethod3()
        {
            //Arrage
            //create cards
            //Card 1
            var Cards = new Card[5];
            Cards[0] = new Card();
            Cards[0].Id = 1;
            Cards[0].WalletId = 1;
            Cards[0].CardType = "MC";
            Cards[0].Balance = 100f;
            Cards[0].Interest = 0f;
            //Card 2
            Cards[1] = new Card();
            Cards[1].Id = 2;
            Cards[1].WalletId = 1;
            Cards[1].CardType = "Visa";
            Cards[1].Balance = 100f;
            Cards[1].Interest = 0f;
            //Card 3
            Cards[2] = new Card();
            Cards[2].Id = 3;
            Cards[2].WalletId = 1;
            Cards[2].CardType = "Discover";
            Cards[2].Balance = 100f;
            Cards[2].Interest = 0f;
            //Card 4
            Cards[3] = new Card();
            Cards[3].Id = 4;
            Cards[3].WalletId = 2;
            Cards[3].CardType = "Visa";
            Cards[3].Balance = 100f;
            Cards[3].Interest = 0f;
            //Card 5
            Cards[4] = new Card();
            Cards[4].Id = 5;
            Cards[4].WalletId = 2;
            Cards[4].CardType = "MC";
            Cards[4].Balance = 100f;
            Cards[4].Interest = 0f;

            //create wallets
            //Wallet 1
            var Wallets = new Wallet[2];
            Wallets[0] = new Wallet();
            Wallets[0].Id = 1;
            Wallets[0].PersonId = 1;
            Wallets[0].Cards = Cards;
            Wallets[0].WalletInterest = 0f;
            //Wallet 2
            Wallets[1] = new Wallet();
            Wallets[1].Id = 2;
            Wallets[1].PersonId = 2;
            Wallets[1].Cards = Cards;
            Wallets[1].WalletInterest = 0f;

            //create people
            //Person 1
            var Person = new Person[2];
            Person[0] = new Person();
            Person[0].Id = 1;
            Person[0].Wallets = Wallets;
            Person[0].PersonInterest = 0f;
            //Person 2
            Person[1] = new Person();
            Person[1].Id = 2;
            Person[0].Wallets = Wallets;
            Person[0].PersonInterest = 0f;

            float person1InterestExpected = 16f;
            float person2InterestExpected = 15f;
            float wallet1InterestExpected = 16f;
            float wallet2InterestExpected = 15f;
            //Act
            float person1InterestActual = Person[0].calculatePersonInterest(Person[0].Wallets);
            float person2InterestActual = Person[1].calculatePersonInterest(Person[0].Wallets);
            float wallet1InterestActual = Wallets[0].WalletInterest;
            float wallet2InterestActual = Wallets[1].WalletInterest;

            //Assert
            //Person 1 Total Interest Test
            Assert.AreEqual(person1InterestExpected, person1InterestActual);
            //Person 2 Total Interest Test
            Assert.AreEqual(person2InterestExpected, person2InterestActual);
            //Wallet 1 Interest Test
            Assert.AreEqual(wallet1InterestExpected, wallet1InterestActual);
            //Wallet 2 Interest Test
            Assert.AreEqual(wallet2InterestExpected, wallet2InterestActual);
        }
    }
}
