﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApplication1;
using Xunit;

namespace ConsoleApplication1.Tests
{
    public class ProgramTests
    {
        public void UnitTestCase1()
        {
            //Arrange
            double expected = 5;
            //Act
            double actual = 5;
            //Assert
            Assert.Equal(expected, actual);
        }
    }
}
